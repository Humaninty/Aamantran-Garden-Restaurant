Aamantran Garden Restaurant — Demo V2

This version adds:
- Real public ambience photo as a temporary demo reference
- Selected online-menu items and prices
- Menu category filters
- Gallery section
- Call, WhatsApp and Google Maps buttons
- Working WhatsApp enquiry form
- Responsive mobile/desktop design

IMPORTANT FOR CLIENT DELIVERY:
Replace the demo photo with owner-approved/licensed photos and verify all menu prices, opening hours, phone and address before publishing.
